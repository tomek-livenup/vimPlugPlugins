## Test 1: Multi Narrowed Window for several distinct buffers ##
