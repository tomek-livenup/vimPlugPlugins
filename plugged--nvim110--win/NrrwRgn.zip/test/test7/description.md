## Test 6: Make sure, highlighting is removed after aborting narrowed window (issue #44)
