## Test 2: Single Narrowed Window for a single buffers ##
