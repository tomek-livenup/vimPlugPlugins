## Test 6: Make sure, highlighting is removed after closing narrowed window (for visual narrowed region)
