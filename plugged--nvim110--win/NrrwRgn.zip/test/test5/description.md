## Test 5: Make sure, highlighting is removed after closing narrowed window
