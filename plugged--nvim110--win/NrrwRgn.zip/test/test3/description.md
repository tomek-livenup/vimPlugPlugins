## Test 2: Single Narrowed Window for a single buffer, but has another split window ##
