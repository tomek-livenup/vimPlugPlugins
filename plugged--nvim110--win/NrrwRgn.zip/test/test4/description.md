## Test 4: Single Narrowed Window for a single buffer, switching back and forth between buffers several times (issue #44)
