# Build Status

| Service        | Status           |
| ------------- |:-------------:|
| GitHub Actions | [![CI](../../actions/workflows/ci.yml/badge.svg)](../../actions/workflows/ci.yml) |

# open-browser.vim

Open URI with your favorite browser from your most favorite editor.


# Derivative plugins

* [tyru/open-browser-github.vim](https://github.com/tyru/open-browser-github.vim)
* [tyru/open-browser-unicode.vim](https://github.com/tyru/open-browser-unicode.vim)
