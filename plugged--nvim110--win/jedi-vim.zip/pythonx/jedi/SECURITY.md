# Security Policy

If security issues arise, we will try to fix those as soon as possible.

Due to Jedi's nature, Security Issues will probably be extremely rare, but we will of course treat them seriously.

## Reporting Security Problems

If you need to report a security vulnerability, please send an email to davidhalter88@gmail.com. Typically, I will respond in the next few business days.
