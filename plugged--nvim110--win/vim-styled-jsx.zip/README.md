# vim-styled-jsx

Vim syntax for [styled-jsx](https://github.com/zeit/styled-jsx).

Sets the syntax to CSS for the contents of `<script jsx>` tags:
