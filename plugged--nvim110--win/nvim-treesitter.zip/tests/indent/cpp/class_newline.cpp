class Foo
{
    int x;
    class Bar
    {
        int y;
    };
    Bar z;
};
