fn foo() {
    for (
        a,
        b
    ) in c.iter() {
        // ...
    }
}
