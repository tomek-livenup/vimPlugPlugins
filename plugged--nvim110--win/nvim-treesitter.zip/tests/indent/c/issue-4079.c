int main(){
    for(;;)
}

int foo(){
    while(1)
}
