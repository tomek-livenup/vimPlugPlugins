#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>

char *a = "a" "b" "c" D;

static int a, b, c;
a = b = c = 0;

static int d = 0, e = 0, f = 0;

int main(void) {
    printf("String" PRIu64 "\n", (uint64_t)0);
    printf("String" AND_ERROR_NODE "and string");
    fflush(stdout);
    a = 0; b = 0; c = 0;
    int x = 0; int y = 0; int z = 0;
    foo(1, 2);
    x++;
    a = b
        = c
        = d;
}
