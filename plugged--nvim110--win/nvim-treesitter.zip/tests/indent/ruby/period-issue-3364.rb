class User < ApplicationRecord
  def foo
    if true
      self.
    end
  end
end
