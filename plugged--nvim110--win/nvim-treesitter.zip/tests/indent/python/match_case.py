a = 0

def test_match_case():
    match a:
        case 1:
            return


def test_match():
    match a:


def test_case():
    match a:
        case b:
