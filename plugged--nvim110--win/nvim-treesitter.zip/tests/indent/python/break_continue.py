def f():
    for x in range(1, 2):
        if x == 1:
            break

def f():
    for x in range(1, 2):
        if x == 1:
            continue
