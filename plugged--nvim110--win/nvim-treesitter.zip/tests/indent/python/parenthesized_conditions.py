if (
    True
    or 1
    or False
):
    pass

if (
    True
    or 1
        or False):
    pass

if (True
    or 1
        or False):
    pass

while (
    False
    or 1
    or False
):
    pass

while (
    False
    or 1
        or False):
    pass

while (False
       or 1
       or False):
    pass
