def test_branch_else():
    if True:
        x = 1
