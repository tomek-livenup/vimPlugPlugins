def hanging_indent(
        arg1, arg2):
    pass

hanging_indent(
    1, 2)
