<?php

function test() {
    $array = [
    ]
}
