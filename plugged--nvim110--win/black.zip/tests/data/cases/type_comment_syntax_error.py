def foo(
    # type: Foo
    x): pass

# output

def foo(
    # type: Foo
    x,
):
    pass
