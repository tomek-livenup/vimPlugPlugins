# flags: --line-length=0
importA;()<<0**0#

# output

importA
(
    ()
    << 0
    ** 0
)  #
