# flags: --unstable
f"{''=}" f'{""=}'