some_variable = "This string is long but not so long that it needs to be split just yet"
some_variable = 'This string is long but not so long that it needs to be split just yet'
some_variable = "This string is long, just long enough that it needs to be split, u get?"
some_variable = 'This string is long, just long enough that it needs to be split, u get?'
some_variable = "This string is long, just long enough that it needs to be split, u get? So we stay"
some_variable = 'This string is long, just long enough that it needs to be split, u get? So we stay'
some_variable = "This string is long, just long enough that it needs to be split, u get? So we split"
some_variable = 'This string is long, just long enough that it needs to be split, u get? So we split'
some_variable = "This string is long but not so long that it needs hahahah toooooo be so greatttt {} that I just can't think of any more good words to say about it at alll".format("ha")
some_variable = "This string is long but not so long that it needs hahahah toooooo be so greatttt {} that I just can't think of any more good words to say about it at allll".format("ha")
some_variable = "This string is long but not so long that it needs hahahah toooooo be so greatttt {} that I just can't think of any more good words to say about it at alllllllllll".format("ha")
some_variable = "This string is long but not so long that it needs hahahah toooooo be so greatttt {} that I just can't think of any more good words to say about it at allllllllllll".format("ha")
some_variable = "This is a long string that will end with a method that is not calleddd".format
addition_inside_tuple = (
    some_string_inside_a_variable
    + "Some string that is just long enough to cause a split to take place.............",
    xyz,
    "Some really long string that needs to get split eventually but I'm running out of things to say" + some_string_inside_a_variable
)
addition_inside_tuple = (
    some_string_inside_a_variable
    + "Some string that is just long enough to cause a split to take place.............."
)
return "Hi there. This is areally really reallllly long string that needs to be split!!!"
ternary_expression = (
    "Short String"
    if some_condition
    else "This is a really long string that will eventually need to be split right here."
)
return f'{x}/b/c/d/d/d/dadfjsadjsaidoaisjdsfjaofjdfijaidfjaodfjaoifjodjafojdoajaaaaaaaaaaa'
return f'{x}/b/c/d/d/d/dadfjsadjsaidoaisjdsfjaofjdfijaidfjaodfjaoifjodjafojdoajaaaaaaaaaaaa'


# output


some_variable = "This string is long but not so long that it needs to be split just yet"
some_variable = "This string is long but not so long that it needs to be split just yet"
some_variable = (
    "This string is long, just long enough that it needs to be split, u get?"
)
some_variable = (
    "This string is long, just long enough that it needs to be split, u get?"
)
some_variable = (
    "This string is long, just long enough that it needs to be split, u get? So we stay"
)
some_variable = (
    "This string is long, just long enough that it needs to be split, u get? So we stay"
)
some_variable = (
    "This string is long, just long enough that it needs to be split, u get? So we"
    " split"
)
some_variable = (
    "This string is long, just long enough that it needs to be split, u get? So we"
    " split"
)
some_variable = (
    "This string is long but not so long that it needs hahahah toooooo be so greatttt"
    " {} that I just can't think of any more good words to say about it at alll".format(
        "ha"
    )
)
some_variable = (
    "This string is long but not so long that it needs hahahah toooooo be so greatttt"
    " {} that I just can't think of any more good words to say about it at allll"
    .format("ha")
)
some_variable = (
    "This string is long but not so long that it needs hahahah toooooo be so greatttt"
    " {} that I just can't think of any more good words to say about it at alllllllllll"
    .format("ha")
)
some_variable = (
    "This string is long but not so long that it needs hahahah toooooo be so greatttt"
    " {} that I just can't think of any more good words to say about it at"
    " allllllllllll".format("ha")
)
some_variable = (
    "This is a long string that will end with a method that is not calleddd".format
)
addition_inside_tuple = (
    some_string_inside_a_variable
    + "Some string that is just long enough to cause a split to take"
    " place.............",
    xyz,
    "Some really long string that needs to get split eventually but I'm running out of"
    " things to say"
    + some_string_inside_a_variable,
)
addition_inside_tuple = (
    some_string_inside_a_variable
    + "Some string that is just long enough to cause a split to take"
    " place.............."
)
return (
    "Hi there. This is areally really reallllly long string that needs to be split!!!"
)
ternary_expression = (
    "Short String"
    if some_condition
    else (
        "This is a really long string that will eventually need to be split right here."
    )
)
return (
    f"{x}/b/c/d/d/d/dadfjsadjsaidoaisjdsfjaofjdfijaidfjaodfjaoifjodjafojdoajaaaaaaaaaaa"
)
return f"{x}/b/c/d/d/d/dadfjsadjsaidoaisjdsfjaofjdfijaidfjaodfjaoifjodjafojdoajaaaaaaaaaaaa"
