vim -Nu .github/.vimrc -c 'Vader! tests/VimPlugin/*'
