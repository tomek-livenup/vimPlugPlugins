Language Server
===============

Phpactor provides many internal extension points for the language server.

.. note::

   This documentation is incomplete.

.. toctree::
   :maxdepth: 2
   :glob:

   language-server/code-action.rst
