Help
====

You can view this manual in VIM by typing ``:help phpactor``

.. include:: ../phpactor.txt
   :literal:
