Tips
====

.. toctree::
   :maxdepth: 2

   tips/performance
