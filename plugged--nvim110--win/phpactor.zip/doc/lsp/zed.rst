.. _lsp_client_zed:

Zed
===

Phpactor is the default LSP for Zed. Install Zed's `PHP extension <https://zed.dev/docs/languages/php>`_.
