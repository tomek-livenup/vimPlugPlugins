.. _language_server_clients:

Clients
=======

.. toctree::
   :maxdepth: 2

   vim
   sublime
   vscode
   emacs
   helix
   nova
   zed

.. toctree::
   :hidden:

   vim-lsp
