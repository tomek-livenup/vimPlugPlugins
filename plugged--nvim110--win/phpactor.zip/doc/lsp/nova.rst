.. _lsp_client_nova:

Nova Code Editor
================

Download the Phpactor extension from the `Nova Extensions Library <https://extensions.panic.com/extensions/emran-mr/emran-mr.phpactor/>`_.
