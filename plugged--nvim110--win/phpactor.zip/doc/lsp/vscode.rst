.. _lsp_client_vscode:

VS Code
=======

Phpactor provides the `phpactor-vscode <https://github.com/phpactor/vscode-phpactor>`_ extension.
