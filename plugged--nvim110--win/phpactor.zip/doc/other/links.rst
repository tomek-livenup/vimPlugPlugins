Links and Resources
===================

This page collects links to resources about, or featuring, Phpactor.

General
-------

-  `Extending
   Phpactor <https://www.dantleech.com/blog/2018/11/25/extensions>`__
-  `3 years of
   Phpactor <https://www.dantleech.com/blog/2018/08/19/phpactor-3-years/>`__

VIM Guides
----------

-  `VIM as an alternative to
   PHPStorm <https://harings.be/vim-as-an-alternative-to-phpstorm-r8z7l>`__
-  `VIM for PHP <https://web-techno.net/vim-php-ide/>`__
-  `Neovim and PHP <https://kushellig.de/neovim-php-ide/>`__
-  `VimでPHPを書くならPhpactorを使うと便利そう(入力補完・ジャンプ・リファクタリング) <https://qiita.com/cyrt/items/ff5edd392b3f41dd6e10>`__
-  `Switchig from VIM to
   Neovim <https://matthewdaly.co.uk/blog/2018/09/09/switching-from-vim-to-neovim/>`__
