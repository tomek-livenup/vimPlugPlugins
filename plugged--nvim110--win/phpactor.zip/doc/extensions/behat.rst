Behat
=====

.. github-link:: phpactor/behat-extension

The Behat extension provides goto definition support and basic completion.

Installation
------------

.. code:: bash

    $ phpactor extension:install phpactor/behat-extension
