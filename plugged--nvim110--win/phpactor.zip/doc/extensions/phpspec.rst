Phpspec
=======

.. github-link:: phpactor/phpspec-extension

The PHPSpec extension provides subject-under-test member completion.

Installing
----------

.. code:: bash

    $ phpactor extension:install phpactor/phpspec-extension
