PHPUnit
=======

.. github-link:: phpactor/phpunit-extension


The PHPUnit extension provides test class generation and type inference.

Installing
----------

.. code:: bash

    $ phpactor extension:install phpactor/phpunit-extension


