Usage
=====

.. toctree::
   :maxdepth: 2

   usage/getting-started
   usage/standalone
   usage/configuration
   usage/language-server
   usage/vim-plugin
