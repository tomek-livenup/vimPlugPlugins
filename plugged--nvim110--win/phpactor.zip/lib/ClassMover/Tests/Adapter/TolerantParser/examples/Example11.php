<?php

use Foobar\Example as BadExample;

class Example extends BadExample
{
}
