<?php

namespace Acme;

class Hello
{
    public function something(): void
    {
        Barfoo::foobar();
    }
}
