<?php

namespace Acme;

enum Hello
{
    case Foo;
}
