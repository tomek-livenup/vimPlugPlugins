<?php

namespace Acme\ClassMover\Tests\Adapter\TolerantParser;

trait ExampleTrait
{
}
