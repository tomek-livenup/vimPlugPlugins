<?php

namespace Acme\ClassMover\Tests\Adapter\TolerantParser;

interface Example5Interface
{
}
