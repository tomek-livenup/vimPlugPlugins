<?php

use Foobar\Example as BadExample;

class ClassOne
{
    public function build(): BadExample
    {
    }
}
