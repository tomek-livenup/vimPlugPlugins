<?php

class ClassOne
{
    public function build(): Example
    {
    }
}
