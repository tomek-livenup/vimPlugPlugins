<?php
class Generic
{
    public function __construct(\FQN\Class $test)
    {
    }
}
