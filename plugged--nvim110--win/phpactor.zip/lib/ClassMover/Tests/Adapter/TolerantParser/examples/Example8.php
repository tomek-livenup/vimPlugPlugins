<?php

class ClassOne
{
    public function build()
    {
        return new self();
    }
}
