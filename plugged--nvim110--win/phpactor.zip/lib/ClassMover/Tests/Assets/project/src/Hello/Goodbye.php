<?php

namespace Acme\Hello;

class Goodbye
{
}
