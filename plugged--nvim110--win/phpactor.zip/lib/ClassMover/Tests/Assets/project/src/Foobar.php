<?php

namespace Acme\Foobar;

class Foobar
{
}
