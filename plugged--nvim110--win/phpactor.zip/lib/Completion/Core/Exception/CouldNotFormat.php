<?php

namespace Phpactor\Completion\Core\Exception;

use Exception;

class CouldNotFormat extends Exception
{
}
