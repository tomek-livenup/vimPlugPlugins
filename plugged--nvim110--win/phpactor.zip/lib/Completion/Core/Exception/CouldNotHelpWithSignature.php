<?php

namespace Phpactor\Completion\Core\Exception;

use Exception;

class CouldNotHelpWithSignature extends Exception
{
}
