<?php

namespace Phpactor\Completion\Tests;

use Phpactor\TestUtils\PHPUnit\TestCase as PhpactorTestCase;

class TestCase extends PhpactorTestCase
{
}
