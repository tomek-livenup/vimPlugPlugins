<?php

class WithoutNS
{
}
