<?php

namespace Test\Name;

class Clapping
{
}
