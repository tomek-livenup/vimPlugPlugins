<?php

namespace Phpactor\CodeTransform\Domain\Exception;

use Exception;

class TransformException extends Exception
{
}
