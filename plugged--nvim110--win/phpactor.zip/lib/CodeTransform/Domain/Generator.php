<?php

namespace Phpactor\CodeTransform\Domain;

/**
 * Marker interface for generators
 */
interface Generator
{
}
