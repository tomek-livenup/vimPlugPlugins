---@brief
---
--- https://github.com/1c-syntax/bsl-language-server
---
--- Language Server Protocol implementation for 1C (BSL) - 1C:Enterprise 8 and OneScript languages.

return {
  filetypes = { 'bsl', 'os' },
  root_markers = { '.git' },
}
