---@brief
---
--- [Circom Language Server](https://github.com/rubydusa/circom-lsp)
---
--- `circom-lsp`, the language server for the Circom language.
return {
  cmd = { 'circom-lsp' },
  filetypes = { 'circom' },
  root_markers = { '.git' },
}
