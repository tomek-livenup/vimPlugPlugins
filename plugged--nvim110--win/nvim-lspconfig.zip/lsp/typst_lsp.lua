---@brief
---
--- https://github.com/nvarner/typst-lsp
---
--- Language server for Typst.
return {
  cmd = { 'typst-lsp' },
  filetypes = { 'typst' },
  root_markers = { '.git' },
}
