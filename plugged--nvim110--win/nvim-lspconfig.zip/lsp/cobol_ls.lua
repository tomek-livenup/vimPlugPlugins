---@brief
---
--- Cobol language support
return {
  cmd = { 'cobol-language-support' },
  filetypes = { 'cobol' },
  root_markers = { '.git' },
}
