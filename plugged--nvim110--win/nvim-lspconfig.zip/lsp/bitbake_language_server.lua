---@brief
---
--- 🛠️ bitbake language server
return {
  cmd = { 'bitbake-language-server' },
  filetypes = { 'bitbake' },
  root_markers = { '.git' },
}
