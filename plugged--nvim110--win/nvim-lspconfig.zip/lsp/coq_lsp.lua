---@brief
---
--- https://github.com/ejgallego/coq-lsp/
return {
  cmd = { 'coq-lsp' },
  filetypes = { 'coq' },
  root_markers = { '_CoqProject', '.git' },
}
