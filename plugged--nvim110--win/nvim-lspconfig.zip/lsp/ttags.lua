---@brief
---
--- https://github.com/npezza93/ttags
return {
  cmd = { 'ttags', 'lsp' },
  filetypes = { 'ruby', 'rust', 'javascript', 'haskell' },
  root_markers = { '.git' },
}
