---@brief
---
--- https://github.com/coq-community/vscoq
return {
  cmd = { 'vscoqtop' },
  filetypes = { 'coq' },
  root_markers = { '_CoqProject', '.git' },
}
