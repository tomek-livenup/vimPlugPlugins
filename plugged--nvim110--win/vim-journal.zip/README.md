# vim-journal

![](https://cloud.githubusercontent.com/assets/700826/7340304/6763bb9a-ecc5-11e4-998b-7dd9b0b12195.png)
