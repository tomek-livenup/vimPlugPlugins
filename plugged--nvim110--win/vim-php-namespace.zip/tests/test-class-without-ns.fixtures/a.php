<?php

class Foo {
}

