<?php

namespace Abc {
    class Def {
    }
}

namespace Foo {
    class Bar {
    }
}

