<?php

namespace Foo;

/*final*/ class Bar {
}

