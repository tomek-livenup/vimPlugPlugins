<?php

namespace Foo;

enum BarEnum {
}

enum BazEnum: string {
}
