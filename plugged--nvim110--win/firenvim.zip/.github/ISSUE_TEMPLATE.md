<!--

If you are reporting a bug and you have a little bit of time,
please check out the troubleshooting guide: https://github.com/glacambre/firenvim/blob/master/TROUBLESHOOTING.md

In case of a feature request, feel free to ggdG ;)

-->

- OS Version:
- Browser Version:
- Browser Addon Version:
- Neovim Plugin Version:

### What I tried to do


### What happened
