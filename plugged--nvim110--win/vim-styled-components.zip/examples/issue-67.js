const body = css.global`
  body {
    margin: 0;
  }
`;

const link = css.resolve`
  a {
    color: green;
  }
`;
