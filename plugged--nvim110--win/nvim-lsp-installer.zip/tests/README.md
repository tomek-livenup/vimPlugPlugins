Refer to https://github.com/williamboman/nvim-lspconfig-test for system tests.
