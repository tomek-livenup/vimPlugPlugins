<?php
$a = 1;
