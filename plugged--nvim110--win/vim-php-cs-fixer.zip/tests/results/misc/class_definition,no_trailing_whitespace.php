<?php
class Aaa implements
    Symfony\CS\Tests\Fixer,
    \RFb,
    \Fcc1,
    \GFdd
{
}
