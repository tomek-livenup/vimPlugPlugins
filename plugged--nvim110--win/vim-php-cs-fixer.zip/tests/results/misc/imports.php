<?php

namespace Acme;

use \Foo;
use BBB\Bar;

use Abc;
use \Barr;
use \Zzzz;
