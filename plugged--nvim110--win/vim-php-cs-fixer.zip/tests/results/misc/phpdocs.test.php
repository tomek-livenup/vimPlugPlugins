<?php

class Foo
{
    /**
     * @access public
     */
    public $bar;

    /**
     * @type array $baz
     */
    public $baz;

/**
 *
 * Hoge
 *
 * @throws Exception
 * @param inTeGer $fo This is int.
 *
 * @param float $bar This is float.
 * @return void
 *
 *
 * @custom
 */
    public function Hoge($fo, $bar, array $baz, $qux)
    {
    }
}
